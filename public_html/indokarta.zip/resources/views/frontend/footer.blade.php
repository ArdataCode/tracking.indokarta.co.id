<section class="elementor-section elementor-top-section elementor-element elementor-element-5a396aad elementor-section-full_width elementor-section-height-default elementor-section-height-default"
data-id="5a396aad"
data-element_type="section"
data-settings='{"background_background":"classic"}'
>
<div class="elementor-container elementor-column-gap-no">
    <div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-230dd35" data-id="230dd35" data-element_type="column" data-settings='{"background_background":"classic"}'>
        <div class="elementor-widget-wrap elementor-element-populated">
            <div class="elementor-element elementor-element-20097bb elementor-widget elementor-widget-heading" data-id="20097bb" data-element_type="widget" data-widget_type="heading.default">
                <div class="elementor-widget-container">
                    <div class="elementor-heading-title elementor-size-default">Info Kontak</div>
                </div>
            </div>
        </div>
    </div>
    <div class="elementor-column elementor-col-66 elementor-top-column elementor-element elementor-element-5a3c29a9" data-id="5a3c29a9" data-element_type="column" data-settings='{"background_background":"classic"}'>
        <div class="elementor-widget-wrap elementor-element-populated">
            <div
                class="elementor-element elementor-element-5d20bb84 elementor-icon-list--layout-inline elementor-align-center elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list"
                data-id="5d20bb84"
                data-element_type="widget"
                data-widget_type="icon-list.default"
            >
                <div class="elementor-widget-container">
                    <link rel="stylesheet" href="{{asset('frontpage/content/plugins/elementor/assets/css/widget-icon-list.min.css')}}" />
                    <ul class="elementor-icon-list-items elementor-inline-items">
                        <li class="elementor-icon-list-item elementor-inline-item">
                            <span class="elementor-icon-list-icon"> <i aria-hidden="true" class="fas fa-phone-alt"></i></span>
                            <span class="elementor-icon-list-text">(021) 825 96856</span>
                        </li>
                        <li class="elementor-icon-list-item elementor-inline-item">
                            <span class="elementor-icon-list-icon"> <i aria-hidden="true" class="fab fa-whatsapp"></i></span>
                            <span class="elementor-icon-list-text">082114153461</span>
                        </li>
                        <li class="elementor-icon-list-item elementor-inline-item">
                            <span class="elementor-icon-list-icon"> <i aria-hidden="true" class="far fa-envelope"></i></span>
                            <span class="elementor-icon-list-text">customer.care@indokarta.co.id</span>
                        </li>
                        <li class="elementor-icon-list-item elementor-inline-item">
                            <span class="elementor-icon-list-icon"> <i aria-hidden="true" class="fas fa-map-marker-alt"></i></span>
                            <span class="elementor-icon-list-text">Jl. Raya Kedaung No.192, RT.001/RW.004, Cimuning, Kec. Mustika Jaya, Kota Bekasi, Jawa Barat 17155</span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
</section>